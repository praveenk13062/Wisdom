// Get modal elements
const authModal = document.getElementById('authModal');
const loginBtn = document.getElementById('loginBtn');
const closeModal = document.getElementById('closeModal');
const usernameDisplay = document.getElementById('usernameDisplay');

// Tab elements
const loginTab = document.getElementById('loginTab');
const registerTab = document.getElementById('registerTab');
const loginForm = document.getElementById('loginForm');
const registerForm = document.getElementById('registerForm');

// Registered users (stored in localStorage)
let registeredUsers = JSON.parse(localStorage.getItem('registeredUsers')) || [];

// On page load, check login and enrollment state
window.addEventListener('DOMContentLoaded', () => {
    const loggedInUser = sessionStorage.getItem('loggedInUser');
    const enrollButton = document.getElementById('enrollButton');

    // Mapping course IDs to their respective HTML filenames
    const coursePageMap = {
        'java': 'java.html',
        'cpp': 'c++.html',
        'python': 'python.html'
    };

    if (loggedInUser) {
        displayLoggedInState(loggedInUser);

        // Check enrollment status for the logged-in user
        let enrolledCourseId = localStorage.getItem(`enrolledCourse_${loggedInUser}`);
        if (enrollButton) {
            if (enrolledCourseId) {
                // User has enrolled in a course
                enrollButton.textContent = "Continue Course";
                enrollButton.href = coursePageMap[enrolledCourseId] || 'course_enroll.html'; // Redirect to the enrolled course page
            } else {
                // User is logged in but not enrolled
                enrollButton.textContent = "Enroll Courses";
                enrollButton.href = "course_enroll.html"; // Redirect to course enrollment page
            }
        }
    } else {
        // No user is logged in
        if (enrollButton) {
            enrollButton.textContent = "Enroll Courses";
            enrollButton.href = "course_enroll.html"; // Redirect to course enrollment page
        }
    }
});

// Show modal when login button is clicked
loginBtn.addEventListener('click', (event) => {
    event.preventDefault(); // Prevent default link behavior
    authModal.style.display = 'flex'; // Show the modal
});

// Close modal when close button is clicked
closeModal.addEventListener('click', () => {
    authModal.style.display = 'none'; // Hide the modal
});

// Close modal when clicking outside of modal content
window.addEventListener('click', (event) => {
    if (event.target === authModal) {
        authModal.style.display = 'none'; // Hide the modal
    }
});

// Tab functionality
loginTab.addEventListener('click', () => {
    loginTab.classList.add('active');
    registerTab.classList.remove('active');
    loginForm.style.display = 'block';
    registerForm.style.display = 'none';
});

registerTab.addEventListener('click', () => {
    registerTab.classList.add('active');
    loginTab.classList.remove('active');
    loginForm.style.display = 'none';
    registerForm.style.display = 'block';
});

// Helper function to update UI for logged-in state
function displayLoggedInState(username) {
    loginBtn.style.display = 'none'; // Hide the login button
    usernameDisplay.style.display = 'block'; // Show the username display

    // Show the welcome message with hover functionality
    usernameDisplay.innerHTML = `
        <span class="welcome-message" id="signOutMessage">Welcome, ${username}!</span>
    `;

    const welcomeMessage = document.getElementById('signOutMessage');

    // Add event listener for sign-out functionality
    welcomeMessage.addEventListener('click', () => {
        sessionStorage.removeItem('loggedInUser'); // Remove login state
        alert('You have been signed out successfully.');

        // Reset UI state
        usernameDisplay.style.display = 'none'; // Hide the username display
        loginBtn.style.display = 'inline-block'; // Show the login button

        // Update Enroll Button after logout
        const enrollButton = document.getElementById('enrollButton');
        if (enrollButton) {
            enrollButton.textContent = "Enroll Courses";
            enrollButton.href = "course_enroll.html"; // Reset button link
        }

        // Refresh the page to update enrollment status
        location.reload();
    });
}

// Validation for login
loginForm.addEventListener('submit', (event) => {
    event.preventDefault();

    const username = document.getElementById('username').value.trim();
    const password = document.getElementById('password').value.trim();

    if (!username || !password) {
        alert('Please enter both username and password.');
        return;
    }

    // Check if the entered credentials match any registered user
    const user = registeredUsers.find(
        (user) => user.username === username && user.password === password
    );

    if (user) {
        alert(`Login successful! Welcome, ${user.username}`);
        sessionStorage.setItem('loggedInUser', user.username); // Save login status
        displayLoggedInState(user.username); // Update UI
        authModal.style.display = 'none'; // Close modal

        // Update Enroll Button after login
        const enrollButton = document.getElementById('enrollButton');
        if (enrollButton) {
            let enrolledCourse = localStorage.getItem(`enrolledCourse_${user.username}`);
            if (enrolledCourse) {
                enrollButton.textContent = "Continue Course";
                enrollButton.href = `${enrolledCourse}.html`; // Redirect to the enrolled course page
            } else {
                enrollButton.textContent = "Enroll Courses";
                enrollButton.href = "course_enroll.html"; // Redirect to course enrollment page
            }
        }
    } else {
        alert('Invalid username or password.');
    }
});

// Validation for registration
registerForm.addEventListener('submit', (event) => {
    event.preventDefault();

    const username = document.getElementById('reg-username').value.trim();
    const email = document.getElementById('email').value.trim();
    const password = document.getElementById('reg-password').value.trim();
    const confirmPassword = document.getElementById('confirm-password').value.trim();

    const emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    const passwordPattern = /^(?=.*[A-Za-z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;

    if (!username) {
        alert('Please enter a username.');
        return;
    }

    if (!emailPattern.test(email)) {
        alert('Please enter a valid email address.');
        return;
    }

    if (!passwordPattern.test(password)) {
        alert(
            'Password must be at least 8 characters long, contain at least one letter, one number, and one special character.'
        );
        return;
    }

    if (password !== confirmPassword) {
        alert('Passwords do not match.');
        return;
    }

    const existingUser = registeredUsers.find(
        (user) => user.username === username || user.email === email
    );

    if (existingUser) {
        alert('Username or email already registered. Please use a different one.');
        return;
    }

    registeredUsers.push({ username, email, password });
    localStorage.setItem('registeredUsers', JSON.stringify(registeredUsers)); // Save to localStorage

    alert('Registration successful! You can now log in with your credentials.');

    registerTab.classList.remove('active');
    loginTab.classList.add('active');
    loginForm.style.display = 'block';
    registerForm.style.display = 'none';
});

// Enroll Button Functionality
document.addEventListener('DOMContentLoaded', () => {
    const enrollButton = document.getElementById('enrollButton');

    if (enrollButton) {
        enrollButton.addEventListener('click', (event) => {
            const loggedInUser = sessionStorage.getItem('loggedInUser');

            if (!loggedInUser) {
                event.preventDefault();
                alert('Please log in before enrolling in a course.');
            } else {
                let enrolledCourse = localStorage.getItem(`enrolledCourse_${loggedInUser}`);

                if (enrolledCourse) {
                    // User is already enrolled, the href is already set to the course page
                    // No additional action needed
                } else {
                    // User is not enrolled, redirecting to course_enroll.html
                    // The href is already set to 'course_enroll.html'
                    // No additional action needed here
                }
            }
        });
    }
});

// Course Enrollment Page Logic (course_enroll.html)
// This needs to be included on the course_enroll.html page
// Ensure that this script runs only on course_enroll.html

// Check if we are on the course_enroll.html page
if (window.location.pathname.endsWith('course_enroll.html')) {
    document.addEventListener('DOMContentLoaded', () => {
        const courseForm = document.getElementById('courseForm');

        if (courseForm) {
            courseForm.addEventListener('submit', (event) => {
                event.preventDefault();

                const loggedInUser = sessionStorage.getItem('loggedInUser');
                if (!loggedInUser) {
                    alert('Please log in before enrolling in a course.');
                    return;
                }

                // Get the selected course from the form
                const selectedCourse = document.querySelector('input[name="course"]:checked');

                if (selectedCourse) {
                    const courseName = selectedCourse.value; // e.g., 'java_course', 'python_course', 'cpp_course'
                    localStorage.setItem(`enrolledCourse_${loggedInUser}`, courseName);

                    alert(`You have successfully enrolled in ${courseName.replace('_', ' ')}!`);

                    // Update the Enroll Button on the main page (optional)

                    // Redirect to the course page
                    window.location.href = `${courseName}.html`;
                } else {
                    alert('Please select a course to enroll.');
                }
            });
        }
    });
}

// Contact page
const contactModal = document.getElementById('contactModal');
const contactBtn = document.getElementById('contactBtn');
const closeContactModal = document.getElementById('closeContactModal');

// When the user clicks on the contact button, open the modal
contactBtn.addEventListener('click', () => {
    contactModal.style.display = 'block';
});

// When the user clicks on the close button, close the modal
closeContactModal.addEventListener('click', () => {
    contactModal.style.display = 'none';
});

// When the user clicks outside the modal, close it
window.addEventListener('click', (event) => {
    if (event.target === contactModal) {
        contactModal.style.display = 'none';
    }
});

const contactForm = document.getElementById('contactForm');
const formResponse = document.getElementById('formResponse');

// Handle form submission
contactForm.addEventListener('submit', (event) => {
    event.preventDefault();

    const name = document.getElementById('contact-name').value.trim();
    const email = document.getElementById('contact-email').value.trim();
    const message = document.getElementById('contact-message').value.trim();

    if (!name || !email || !message) {
        alert('Please fill out all fields.');
        return;
    }

    alert('Your message has been sent successfully! We will get back to you soon.');
    formResponse.style.display = 'block';
    formResponse.textContent = 'Thank you for your message! We will get back to you soon.';
    contactForm.reset();
});

function toggleContent(id) {
    var content = document.getElementById(id);
    if (content.style.display === "none") {
        content.style.display = "block";
    } else {
        content.style.display = "none";
    }
}

//sidebar
document.addEventListener('DOMContentLoaded', function () {
    var sidebar = document.getElementById('new-sidebar');
    var toggleBtn = document.getElementById('new-toggle-btn');

    toggleBtn.addEventListener('click', function () {
        if (sidebar.style.left === '-250px') {
            sidebar.style.left = '0';
            toggleBtn.innerHTML = '<i class="fas fa-arrow-left"></i>';
            toggleBtn.classList.add('open');
        } else {
            sidebar.style.left = '-250px';
            toggleBtn.innerHTML = '<i class="fas fa-arrow-right"></i>';
            toggleBtn.classList.remove('open');
        }
    });
});


 //file upload
 function uploadFile() {
    const fileInput = document.getElementById('fileInput');
    if (fileInput.files.length === 0) {
        alert('Please select a file to upload.');
        return;
    }

    const file = fileInput.files[0];
    if (file.type !== 'application/pdf' && file.type !== 'application/vnd.openxmlformats-officedocument.wordprocessingml.document') {
        alert('Please select a PDF or DOCX file.');
        return;
    }

    // Here, you can handle the file upload process
    // For example, you can upload the file to a server or process it in the browser
    console.log('Selected file:', file);
    alert('File uploaded successfully!');
}


//slidshow
let slideIndex = 0;
showSlides();

function showSlides() {
    let slides = document.getElementsByClassName("mySlides");
    for (let i = 0; i < slides.length; i++) {
        slides[i].style.display = "none";  
    }
    slideIndex++;
    if (slideIndex > slides.length) {slideIndex = 1}    
    slides[slideIndex-1].style.display = "block";  
    setTimeout(showSlides, 2000); // Change image every 2 seconds
}
